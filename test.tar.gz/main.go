/*
Copyright © 2023 NAME HERE <EMAIL ADDRESS>

*/
package main

import "orb/cmd"

func main() {
	cmd.Execute()
}
