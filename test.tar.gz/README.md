**USAGE**
go build
go install
orb pushTerraformCode createArchive